
## Deploy in One Click

[![Deploy to Okteto](https://okteto.com/develop-okteto.svg)](https://cloud.okteto.com/deploy?repository=https://github.com/Obysofttt/tguploaderv8okteto)
